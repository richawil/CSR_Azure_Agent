#!/bin/sh

# Install tools and programs to run the CSR in the Azure cloud
#
# This script assumes the guestshell has been configured and enabled on
# the CSR.

# Install the Azure CLI 2.0
if [ ! -e /usr/bin/az ]; then  
    sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc

    sudo sh -c 'echo -e "[azure-cli]\nname=Azure CLI\nbaseurl=https://packages.microsoft.com/yumrepos/azure-cli\nenabled=1\ngpgcheck=1\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc" > /etc/yum.repos.d/azure-cli.repo'

    yum check-update
    sudo yum install azure-cli -y
fi

# Install packages required for Managed Service Identity (MSI)
sudo pip install requests --exists-action abort
sudo yum install at -y
sudo systemctl start atd
sudo systemctl enable atd

# Get an authentication token
python /home/guestshell/msi_token.py
