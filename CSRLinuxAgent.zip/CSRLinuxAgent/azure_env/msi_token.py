#!/usr/bin/env python

"Use the Managed Service Identity service in Azure to get an auth token"

import os
import sys
import requests
import json
import subprocess
import azhadbg

# Specify files accessed by this script
get_response_file = "/home/guestshell/token_get_rsp"
token_file = "/bootflash/token"
debug_file = "/home/guestshell/azhadbg.log"

debug_fh = open(debug_file, 'a')
azhadbg.log(debug_fh, "Requesting new token")

# Specify the HTTP GET request to obtain a token
url      = "http://localhost:50342/oauth2/token"
payload  = {'resource':'https://management.azure.com/'}
header   = {'Metadata':'true'}

# Send the HTTP GET request for the token
response = requests.get(url, params=payload, verify=False, headers=header)

if 200 == response.status_code :
    # Write the HTTP GET response to a file for debugging purposes
    with open(get_response_file, 'wb') as resp_fh:
        for chunk in response.iter_content(chunk_size=64):
            resp_fh.write(chunk)
    azhadbg.log(debug_fh, "Token obtained successfully")
else:
    azhadbg.log(debug_fh, "Token GET request failed with code %d" % response.status_code)
    sys.exit

# Parse the HTTP GET response
token = response.json()["access_token"]

# Write the token to the token file
with open(token_file, 'w') as token_fh:
    token_fh.write(token)

# Calculate the period of time this token is valid
expires_in = response.json()["expires_in"]
azhadbg.log(debug_fh, "Token expires in %d seconds" % int(expires_in))
exp_minutes = (int(expires_in) / 60) - 5
azhadbg.log(debug_fh, "Token will be refreshed in %d minutes" % exp_minutes)

# Schedule a job to invalidate this token
command = "at -f at_command_file now + %d minutes" % exp_minutes
os.system(command)

debug_fh.close

